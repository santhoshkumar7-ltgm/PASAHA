# AutomateX India — AI Automation Agency OS & Client Demo Suite

An end-to-end operational blueprint, business roadmap, and fully interactive AI WhatsApp Assistant demo client designed to launch a profitable AI Automation Company in India from scratch with zero capital investment.

## User Review & Critical Decisions

> [!IMPORTANT]
> The primary pilot domain selected is **Educational Institutions & Coaching Centres** in India, offering the fastest path to the first paying customer due to high admission enquiry volume, repetitive fee/batch questions, and high willingness to pay for student lead capture.

- **Initial Pilot Vertical**: Educational Institutions, NEET/JEE coaching institutes, and tuition centers.
- **Product Architecture**: Interactive Android Founder OS featuring a live WhatsApp Assistant Simulator, Lead CRM Dashboard, Appointment Booker, Revenue & Unit Economics Calculator, and Client Pitch & Outreach Engine.
- **Language Strategy**: Native bilingual support (English and Tanglish / Tamil conversational flow), matching real customer interactions in South India while easily extensible to Hindi and Pan-Indian markets.
- **Zero-Cost Toolchain**: Google Gemini API (free tier / pay-as-you-go), Meta WhatsApp Cloud API (1,000 free service conversations/month), n8n self-hosted / cloud free tier, and FastAPI.

---

## 1. Overview & Core Concept

### What It Does
**AutomateX India** serves a dual purpose for your startup journey:
1. **Founder Companion & Strategic Roadmap (Phase 1)**: Clear breakdown of business economics, pricing models in INR (₹), client outreach scripts for coaching institute directors, cost-vs-profit calculators, and step-by-step milestones to scale from ₹0 to ₹10 Lakhs and beyond.
2. **Interactive Client Demo Suite (Phase 2)**: A live, high-fidelity WhatsApp conversation simulator tailored for coaching academies (e.g., "Apex Academy"). It lets you walk into a coaching center owner's office, hand them your Android device, and let them experience how their inquiries are handled 24/7, appointments are scheduled, and student leads are captured in real-time.

### Target Audience & Persona
- **Yourself (The Founder)**: Tracking customer acquisition, calculating unit economics, viewing n8n webhook blueprints, and managing client pitches.
- **Prospective Business Clients (Coaching Centre Owners / Directors)**: Experiencing interactive product demos during sales calls to see instant ROI before paying an advance setup fee.

### Key Value
- **Zero Capital Required**: Leverages free-tier architectures and generates immediate upfront cash flow (setup fees) to fund operations.
- **Instant Client Trust**: Having a functioning live demo on your phone turns abstract AI ideas into tangible business value within 60 seconds.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Interactive Client WhatsApp Demo**:
   - The user selects a demo business profile (e.g., "Apex NEET & JEE Academy") or customizes their own.
   - A real-time chat interface simulates WhatsApp with student inquiries ("What is the fee for 12th repeater batch?", "Fees evvalavu bro?", "Can I attend a free demo class this Saturday?").
   - The AI Assistant understands English and Tamil/Tanglish, answers curriculum and fee questions accurately, extracts student details (Name, Grade, Phone, Parent Contact), and books a demo session.
   - Shows human agent takeover when a sensitive or complex query is detected.

2. **Lead CRM & Live Activity Stream**:
   - Every lead captured in the chat simulation immediately populates an interactive CRM table with lead scores (Hot/Warm/Cold), contact details, inquiry intent, and status (New, Demo Scheduled, Converted).
   - Filter by course, status, or date; export lead summary.

3. **Appointment & Demo Class Scheduler**:
   - Visual slot management showing available batch timings and counselling slots.
   - Allows simulated booking, rescheduling, and automated WhatsApp reminder dispatch.

4. **Agency Business Hub & Unit Economics Calculator**:
   - Dynamic slider-based pricing calculator (Setup Fee ₹15,000 to ₹35,000 + Monthly Retainer ₹4,999 to ₹14,999).
   - Real cost breakdown: Server cost (₹0-₹800/mo), Gemini API tokens (₹0.05/conversation), WhatsApp Cloud API (Free 1,000 tier), and net profit margin (>85%).
   - Step-by-step roadmap towards ₹50 Crore monthly profit milestone with actionable checkpoints (Phase 1 to Phase 5).

5. **Pitch Deck & Outreach Script Vault**:
   - Cold WhatsApp outreach templates, phone call pitch scripts in Tamil & English, and objection-handling cheat sheets for Indian business owners.

### Visual Identity & Theme
- **Theme Posture**: Luxury Deep Tech Dark / Emerald Modern (`#0B1215` deep slate background with emerald green `#00D26A` WhatsApp accents, crisp neon mint, and gold accents).
- **Typography**: Clean, high-legibility geometric sans-serif hierarchy with robust numeric tabular display for Rupee values (`₹`).
- **Surface Depth**: M3 elevated cards with subtle 1px border glows (`#1A2C2C`), glassmorphic overlays, and tactile ripple feedback.
- **Safe Area Insets**: Edge-to-edge support with safe drawing and navigation bar insets.

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Approach | Rationale | Alternatives Considered |
| :--- | :--- | :--- | :--- |
| **Demo Architecture** | Hybrid On-Device & Gemini Cloud AI | Immediate interactive response with zero lag, falling back to smart contextual response engine if offline, with optional live Gemini API key connectivity. | Requiring external n8n/FastAPI server immediately (would block offline sales demos in coaching centers). |
| **Persistence** | Jetpack Room with Kotlin Flow | Instant local responsiveness, reliable data persistence for leads and client presets, zero hosting bills. | Firestore (adds unnecessary auth gating before client demonstration). |
| **Language Engine** | Tamil + English (Tanglish) Prompt Engineering | Matches real colloquial text behavior of students and parents in Tamil Nadu and South India. | Pure English only (too formal, loses local emotional connect). |
| **Pricing Strategy** | "Setup Fee + Monthly AMC" Model | Gives immediate non-dilutive working capital (₹15,000 - ₹30,000 upfront) while locking in recurring SaaS revenue. | Pure commission (hard to verify with coaching center cash admissions). |

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        AutomateX Android App                           │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌───────────────────────┐  ┌─────────────────┐  ┌──────────────────┐  │
│  │ WhatsApp AI Simulator │  │  Lead CRM & Hub │  │ ROI & Plan Tool  │  │
│  │ (Chat UI, AI Engine)  │  │  (Status, Score)│  │ (Unit Economics) │  │
│  └───────────┬───────────┘  └────────┬────────┘  └────────┬─────────┘  │
│              │                       │                    │            │
│  ┌───────────▼───────────────────────▼────────────────────▼─────────┐  │
│  │                   AutomateX Agency ViewModel                      │  │
│  └───────────────────────────────────┬───────────────────────────────┘  │
│                                      │                                 │
│  ┌───────────────────────────────────▼───────────────────────────────┐  │
│  │            Local Database (Room) & AI Service Layer               │  │
│  │  - LeadDao & Leads Table       - AppointmentDao & Slots Table     │  │
│  │  - Coaching Centre Knowledge   - Gemini / Natural Rule AI Engine  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Entities
1. **LeadEntity**: `id`, `studentName`, `parentPhone`, `targetCourse`, `score` (HOT/WARM/COLD), `inquirySummary`, `status`, `createdAt`.
2. **AppointmentEntity**: `id`, `leadId`, `studentName`, `dateTimestamp`, `slotTime`, `type` (FREE_DEMO/COUNSELLING), `status`.
3. **BusinessProfileEntity**: `id`, `name`, `category`, `address`, `coursesOfferedJson`, `feeStructureJson`, `faqJson`.
4. **OutreachScript**: `title`, `channel`, `language`, `scriptText`, `objectionHandling`.

---

## 5. Verification Plan

### Build & Verification
1. Run `compile_applet` to ensure seamless Kotlin compilation with zero missing imports or broken Jetpack Compose APIs.
2. Verify all UI tabs: WhatsApp Simulator, Lead Management, Appointment Scheduling, Agency Calculator, and Pitch Vault.
3. Verify realistic bilingual conversational interaction in the WhatsApp simulator with automatic lead extraction into the CRM table.
