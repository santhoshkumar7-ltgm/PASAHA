package com.example

import com.example.data.AiAssistantEngine
import com.example.viewmodel.CalculatorState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun aiEngine_detectsTamilFeeInquiry() {
    val engine = AiAssistantEngine()
    val result = engine.processIncomingMessage("Fees evvalavu bro?")
    assertEquals("FEE_INQUIRY_TAMIL", result.detectedIntent)
    assertTrue(result.replyText.contains("Apex NEET Academy"))
  }

  @Test
  fun aiEngine_extractsDemoAppointment() {
    val engine = AiAssistantEngine()
    val result = engine.processIncomingMessage("Can I book a demo class?")
    assertEquals("APPOINTMENT_DEMO_BOOKING", result.detectedIntent)
    assertNotNull(result.bookedAppointment)
    assertNotNull(result.extractedLead)
  }

  @Test
  fun aiEngine_triggersHumanHandoffOnComplaint() {
    val engine = AiAssistantEngine()
    val result = engine.processIncomingMessage("I want a refund and speak to manager")
    assertTrue(result.isHumanHandoff)
    assertEquals("HUMAN_HANDOFF_ESCALATION", result.detectedIntent)
  }

  @Test
  fun calculatorState_computesCorrectMargin() {
    val calc = CalculatorState(clientCount = 5, setupFee = 25000, monthlyRetainer = 6000)
    assertEquals(125000L, calc.totalUpfrontCash)
    assertEquals(30000L, calc.monthlyRecurringRevenue)
    assertTrue(calc.netMonthlyProfit > 28000L)
    assertTrue(calc.profitMarginPercent > 90)
  }
}
