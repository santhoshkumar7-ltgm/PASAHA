package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AgencyStrategyRepository
import com.example.data.AiAssistantEngine
import com.example.data.AiMessage
import com.example.data.AiProcessingResult
import com.example.data.AppDatabase
import com.example.data.MessageSender
import com.example.data.model.AppointmentEntity
import com.example.data.model.LeadEntity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppTab(val title: String) {
  WHATSAPP_SIMULATOR("Live AI Bot"),
  LEAD_CRM("Leads CRM"),
  APPOINTMENTS("Bookings"),
  REVENUE_PLANNER("ROI & Profit"),
  PITCH_VAULT("Pitch Vault")
}

data class CalculatorState(
  val clientCount: Int = 5,
  val setupFee: Int = 25000,
  val monthlyRetainer: Int = 6000,
) {
  val totalUpfrontCash: Long get() = clientCount.toLong() * setupFee
  val monthlyRecurringRevenue: Long get() = clientCount.toLong() * monthlyRetainer
  
  // Real Indian Cloud Economics:
  // Meta Cloud API: 1,000 free service convos/month. Additional ~₹0.35/conversation
  // Gemini 1.5 Flash: ~₹0.01 per conversation
  // VPS Host (FastAPI + PostgreSQL + n8n): ₹800/mo flat
  val estimatedMonthlyExpense: Long get() {
    val hosting = 800L
    val apiCostPerClient = 150L // ~300 inquiries/month per coaching centre
    return hosting + (clientCount * apiCostPerClient)
  }
  
  val netMonthlyProfit: Long get() = (monthlyRecurringRevenue - estimatedMonthlyExpense).coerceAtLeast(0)
  val profitMarginPercent: Int get() = if (monthlyRecurringRevenue > 0) ((netMonthlyProfit.toDouble() / monthlyRecurringRevenue) * 100).toInt() else 0
}

class AgencyViewModel(application: Application) : AndroidViewModel(application) {

  private val database = AppDatabase.getDatabase(application, viewModelScope)
  private val leadDao = database.leadDao()
  private val appointmentDao = database.appointmentDao()
  private val aiEngine = AiAssistantEngine()
  val strategyRepository = AgencyStrategyRepository()

  // Navigation
  private val _currentTab = MutableStateFlow(AppTab.WHATSAPP_SIMULATOR)
  val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

  fun setTab(tab: AppTab) {
    _currentTab.value = tab
  }

  // Live Chat Simulator State
  private val _messages = MutableStateFlow<List<AiMessage>>(emptyList())
  val messages: StateFlow<List<AiMessage>> = _messages.asStateFlow()

  private val _isTyping = MutableStateFlow(false)
  val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

  private val _lastAiResult = MutableStateFlow<AiProcessingResult?>(null)
  val lastAiResult: StateFlow<AiProcessingResult?> = _lastAiResult.asStateFlow()

  private val _humanHandoffActive = MutableStateFlow(false)
  val humanHandoffActive: StateFlow<Boolean> = _humanHandoffActive.asStateFlow()

  // Room Database Flows
  val leads: StateFlow<List<LeadEntity>> = leadDao.getAllLeads().stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  val appointments: StateFlow<List<AppointmentEntity>> = appointmentDao.getAllAppointments().stateIn(
    scope = viewModelScope,
    started = SharingStarted.WhileSubscribed(5000),
    initialValue = emptyList()
  )

  // Calculator State
  private val _calcState = MutableStateFlow(CalculatorState())
  val calcState: StateFlow<CalculatorState> = _calcState.asStateFlow()

  init {
    initChat()
  }

  fun resetChat() {
    initChat()
  }

  private fun initChat() {
    _humanHandoffActive.value = false
    _messages.value = listOf(
      AiMessage(
        sender = MessageSender.BOT,
        text = "Vanakkam! 🙏 Welcome to Apex NEET & JEE Academy WhatsApp Assistant.\n\nI am your 24/7 AI counsellor. How can I help you today?\n• Course Fees & Scholarships\n• Morning & Evening Batch Timings\n• Hostel Facilities\n• Book a Free Trial Demo Class\n\nYou can ask in English or தமிழ்!",
        timestamp = System.currentTimeMillis() - 60000
      )
    )
    _lastAiResult.value = null
  }

  fun sendMessage(userText: String) {
    if (userText.isBlank()) return

    val userMessage = AiMessage(
      sender = MessageSender.USER,
      text = userText,
      timestamp = System.currentTimeMillis()
    )

    _messages.value = _messages.value + userMessage
    _isTyping.value = true

    viewModelScope.launch {
      // Simulate realistic typing delay (800ms)
      delay(900)
      _isTyping.value = false

      val result = aiEngine.processIncomingMessage(userText)
      _lastAiResult.value = result

      if (result.isHumanHandoff) {
        _humanHandoffActive.value = true
      }

      val botMessage = AiMessage(
        sender = if (result.isHumanHandoff) MessageSender.HUMAN_AGENT else MessageSender.BOT,
        text = result.replyText,
        timestamp = System.currentTimeMillis(),
        isHandoffAlert = result.isHumanHandoff
      )

      _messages.value = _messages.value + botMessage

      // Persist newly captured leads directly into Room
      result.extractedLead?.let { lead ->
        leadDao.insertLead(lead)
      }

      // Persist booked appointment directly into Room
      result.bookedAppointment?.let { appt ->
        appointmentDao.insertAppointment(appt)
      }
    }
  }

  fun updateLeadStatus(lead: LeadEntity, newStatus: String) {
    viewModelScope.launch {
      leadDao.updateLead(lead.copy(status = newStatus))
    }
  }

  fun deleteLead(lead: LeadEntity) {
    viewModelScope.launch {
      leadDao.deleteLead(lead)
    }
  }

  fun bookManualAppointment(
    studentName: String,
    phone: String,
    courseName: String,
    slotDate: String,
    slotTime: String,
    type: String
  ) {
    viewModelScope.launch {
      val appt = AppointmentEntity(
        studentName = studentName,
        contactPhone = phone,
        courseName = courseName,
        slotDate = slotDate,
        slotTime = slotTime,
        appointmentType = type,
        status = "CONFIRMED"
      )
      appointmentDao.insertAppointment(appt)
    }
  }

  fun updateAppointmentStatus(appointment: AppointmentEntity, newStatus: String) {
    viewModelScope.launch {
      appointmentDao.updateAppointment(appointment.copy(status = newStatus))
    }
  }

  fun deleteAppointment(appointment: AppointmentEntity) {
    viewModelScope.launch {
      appointmentDao.deleteAppointment(appointment)
    }
  }

  fun updateCalculator(clients: Int, setup: Int, retainer: Int) {
    _calcState.value = CalculatorState(
      clientCount = clients,
      setupFee = setup,
      monthlyRetainer = retainer
    )
  }
}
