package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primary (WhatsApp Emerald & Neon Mint)
val EmeraldPrimary = Color(0xFF00D26A)
val EmeraldDark = Color(0xFF008F48)
val NeonMint = Color(0xFF05E2B5)

// Secondary & Accents
val CyanAccent = Color(0xFF00B4D8)
val GoldAccent = Color(0xFFFFB800)
val AmberAccent = Color(0xFFFF8C00)
val CoralError = Color(0xFFFF5252)

// Dark Theme Surfaces (Deep Slate & Obsidian)
val DarkBackground = Color(0xFF0B1215)
val DarkSurface = Color(0xFF111C21)
val DarkSurfaceVariant = Color(0xFF1A2830)
val DarkSurfaceCard = Color(0xFF142229)
val DarkBorder = Color(0xFF233842)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// WhatsApp Specific Tones
val WhatsAppGreenHeader = Color(0xFF128C7E)
val WhatsAppChatBg = Color(0xFF0C1317)
val WhatsAppBubbleIncoming = Color(0xFF202C33)
val WhatsAppBubbleOutgoing = Color(0xFF005C4B)
val WhatsAppDoubleTickBlue = Color(0xFF53BDEB)
