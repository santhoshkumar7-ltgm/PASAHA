package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LeadEntity
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CoralError
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgencyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LeadCrmScreen(
  viewModel: AgencyViewModel,
  modifier: Modifier = Modifier
) {
  val leads by viewModel.leads.collectAsState()
  var selectedFilter by remember { mutableStateOf("ALL") }
  var showExportDialog by remember { mutableStateOf(false) }
  var actionToastText by remember { mutableStateOf<String?>(null) }

  val filteredLeads = remember(leads, selectedFilter) {
    when (selectedFilter) {
      "HOT" -> leads.filter { it.score == "HOT" }
      "WARM" -> leads.filter { it.score == "WARM" }
      "CONVERTED" -> leads.filter { it.status == "CONVERTED" }
      else -> leads
    }
  }

  val hotCount = leads.count { it.score == "HOT" }
  val demoCount = leads.count { it.status == "DEMO_SCHEDULED" }
  val convertedCount = leads.count { it.status == "CONVERTED" }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(16.dp)
  ) {
    // Header & Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Admissions Lead CRM",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Real-time AI WhatsApp Lead Pipeline",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }

      OutlinedButton(
        onClick = { showExportDialog = true },
        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonMint),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonMint.copy(alpha = 0.5f)),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier.testTag("export_leads_button")
      ) {
        Icon(
          imageVector = Icons.Default.Share,
          contentDescription = null,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("Export CSV", fontSize = 12.sp)
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Analytics Metrics Cards
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      MetricCard(
        title = "Total Leads",
        value = "${leads.size}",
        subtitle = "From WhatsApp",
        accentColor = NeonMint,
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = "Hot Leads",
        value = "$hotCount",
        subtitle = "High Intent 🔥",
        accentColor = CoralError,
        modifier = Modifier.weight(1f)
      )
      MetricCard(
        title = "Demos Booked",
        value = "$demoCount",
        subtitle = "Trial Classes",
        accentColor = GoldAccent,
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Filter Chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("ALL" to "All (${leads.size})", "HOT" to "Hot ($hotCount)", "WARM" to "Warm", "CONVERTED" to "Converted ($convertedCount)").forEach { (key, label) ->
        FilterChip(
          selected = selectedFilter == key,
          onClick = { selectedFilter = key },
          label = { Text(label, fontSize = 12.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = EmeraldDark,
            selectedLabelColor = Color.White,
            containerColor = DarkSurface,
            labelColor = TextSecondary
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selectedFilter == key,
            borderColor = DarkBorder,
            selectedBorderColor = EmeraldPrimary
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Action Toast Notice
    actionToastText?.let { toast ->
      Surface(
        color = Color(0xFF132B20),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 8.dp)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(toast, color = TextPrimary, fontSize = 12.sp)
        }
      }
    }

    // Leads List
    if (filteredLeads.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("No leads in this category yet", color = TextSecondary, fontSize = 14.sp)
          Text("Try sending a demo query in the Live AI Bot tab!", color = TextMuted, fontSize = 12.sp)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
      ) {
        items(filteredLeads, key = { it.id }) { lead ->
          LeadCard(
            lead = lead,
            onStatusChange = { newStatus ->
              viewModel.updateLeadStatus(lead, newStatus)
              actionToastText = "Updated ${lead.studentName} status to $newStatus"
            },
            onDelete = {
              viewModel.deleteLead(lead)
              actionToastText = "Removed lead ${lead.studentName}"
            },
            onSimulateWhatsApp = {
              actionToastText = "Automated WhatsApp follow-up sent to ${lead.parentPhone}"
            },
            onSimulateCall = {
              actionToastText = "Connecting call to ${lead.parentPhone}..."
            }
          )
        }
      }
    }
  }

  // Export Dialog
  if (showExportDialog) {
    AlertDialog(
      onDismissRequest = { showExportDialog = false },
      title = { Text("Export Client Lead Report", color = TextPrimary) },
      text = {
        Column {
          Text(
            "This report can be automatically emailed to the coaching institute director every evening at 8:00 PM via n8n automation.",
            color = TextSecondary,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            color = DarkSurfaceCard,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("CSV Preview Summary:", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text("Total Enquiries: ${leads.size}", color = TextPrimary, fontSize = 12.sp)
              Text("Hot Leads Identified: $hotCount", color = CoralError, fontSize = 12.sp)
              Text("Demo Classes Booked: $demoCount", color = GoldAccent, fontSize = 12.sp)
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            showExportDialog = false
            actionToastText = "Report exported & dispatched to client director via WhatsApp!"
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
        ) {
          Text("Send Client Report")
        }
      },
      dismissButton = {
        TextButton(onClick = { showExportDialog = false }) {
          Text("Close", color = TextSecondary)
        }
      },
      containerColor = DarkSurface
    )
  }
}

@Composable
fun MetricCard(
  title: String,
  value: String,
  subtitle: String,
  accentColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier,
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Text(title, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
      Spacer(modifier = Modifier.height(4.dp))
      Text(value, color = accentColor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(2.dp))
      Text(subtitle, color = TextSecondary, fontSize = 10.sp)
    }
  }
}

@Composable
fun LeadCard(
  lead: LeadEntity,
  onStatusChange: (String) -> Unit,
  onDelete: () -> Unit,
  onSimulateWhatsApp: () -> Unit,
  onSimulateCall: () -> Unit
) {
  var showMenu by remember { mutableStateOf(false) }
  val timeFormatter = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
  val dateStr = remember(lead.timestamp) { timeFormatter.format(Date(lead.timestamp)) }

  val scoreColor = when (lead.score) {
    "HOT" -> CoralError
    "WARM" -> AmberAccent
    else -> NeonMint
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = lead.studentName,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${lead.parentPhone} • $dateStr",
            color = TextSecondary,
            fontSize = 12.sp
          )
        }

        Surface(
          color = scoreColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, scoreColor.copy(alpha = 0.4f))
        ) {
          Text(
            text = "${lead.score} LEAD",
            color = scoreColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Surface(
        color = Color(0xFF1B2830),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = "🎯 ${lead.targetCourse}",
          color = NeonMint,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = lead.inquirySummary,
        color = TextSecondary,
        fontSize = 12.sp,
        lineHeight = 17.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      // Status pill and quick action buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Status toggle dropdown
        Box {
          Surface(
            color = DarkBorder,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.clickable { showMenu = true }
          ) {
            Text(
              text = "Status: ${lead.status.replace("_", " ")} ▾",
              color = TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }

          DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
          ) {
            DropdownMenuItem(
              text = { Text("NEW") },
              onClick = { onStatusChange("NEW"); showMenu = false }
            )
            DropdownMenuItem(
              text = { Text("DEMO SCHEDULED") },
              onClick = { onStatusChange("DEMO_SCHEDULED"); showMenu = false }
            )
            DropdownMenuItem(
              text = { Text("FOLLOW UP") },
              onClick = { onStatusChange("FOLLOW_UP"); showMenu = false }
            )
            DropdownMenuItem(
              text = { Text("CONVERTED") },
              onClick = { onStatusChange("CONVERTED"); showMenu = false }
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          IconButton(
            onClick = onSimulateWhatsApp,
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(Color(0xFF0F3826))
          ) {
            Icon(Icons.Default.Whatshot, contentDescription = "Send WhatsApp", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
          }

          IconButton(
            onClick = onSimulateCall,
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(Color(0xFF1E3A5F))
          ) {
            Icon(Icons.Default.Call, contentDescription = "Call Lead", tint = NeonMint, modifier = Modifier.size(16.dp))
          }

          IconButton(
            onClick = onDelete,
            modifier = Modifier.size(34.dp)
          ) {
            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Lead", tint = TextMuted, modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}
