package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppointmentEntity
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.CoralError
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgencyViewModel

@Composable
fun AppointmentSchedulerScreen(
  viewModel: AgencyViewModel,
  modifier: Modifier = Modifier
) {
  val appointments by viewModel.appointments.collectAsState()
  var showNewBookingDialog by remember { mutableStateOf(false) }
  var feedbackNotice by remember { mutableStateOf<String?>(null) }

  val timeSlots = listOf("10:00 AM", "11:30 AM", "02:00 PM", "04:30 PM", "06:00 PM")
  var selectedSlot by remember { mutableStateOf("10:00 AM") }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "AI Appointment Scheduler",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Automated Demo Class & Counselling Slots",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }

      Button(
        onClick = { showNewBookingDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("book_appointment_button")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("New Slot", fontSize = 12.sp)
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Slot Availability Ribbon
    Surface(
      color = DarkSurfaceCard,
      shape = RoundedCornerShape(10.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("TODAY'S BATCH CAPACITY", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Text("3 of 5 Slots Filled", color = NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(timeSlots) { slot ->
            val isSelected = selectedSlot == slot
            Surface(
              color = if (isSelected) EmeraldDark else Color(0xFF1E2D34),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier.clickable { selectedSlot = slot }
            ) {
              Text(
                text = slot,
                color = if (isSelected) Color.White else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Notice banner
    feedbackNotice?.let { notice ->
      Surface(
        color = Color(0xFF162E22),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 10.dp)
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(notice, color = TextPrimary, fontSize = 12.sp)
        }
      }
    }

    // Appointment List
    Text(
      text = "UPCOMING SCHEDULED SESSIONS (${appointments.size})",
      color = TextMuted,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(vertical = 4.dp)
    )

    if (appointments.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Text("No appointments booked yet. Book one above or test in the WhatsApp Bot!", color = TextSecondary)
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
      ) {
        items(appointments, key = { it.id }) { appt ->
          AppointmentCard(
            appointment = appt,
            onSendReminder = {
              viewModel.updateAppointmentStatus(appt, "REMINDER_SENT")
              feedbackNotice = "WhatsApp Reminder dispatched to ${appt.contactPhone}: 'Dear ${appt.studentName}, your demo class is confirmed for ${appt.slotDate}'"
            },
            onReschedule = { newTime ->
              viewModel.updateAppointmentStatus(appt, "CONFIRMED")
              feedbackNotice = "Rescheduled ${appt.studentName}'s session to $newTime"
            },
            onCancel = {
              viewModel.updateAppointmentStatus(appt, "CANCELLED")
              feedbackNotice = "Cancelled session for ${appt.studentName}"
            },
            onDelete = {
              viewModel.deleteAppointment(appt)
              feedbackNotice = "Removed booking record for ${appt.studentName}"
            }
          )
        }
      }
    }
  }

  // New Booking Dialog
  if (showNewBookingDialog) {
    var studentNameInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var courseInput by remember { mutableStateOf("NEET Repeater Batch") }
    var dateInput by remember { mutableStateOf("Saturday, 10:30 AM") }

    AlertDialog(
      onDismissRequest = { showNewBookingDialog = false },
      title = { Text("Book Demo or Counselling Slot", color = TextPrimary, fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = studentNameInput,
            onValueChange = { studentNameInput = it },
            label = { Text("Student Name") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = EmeraldPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = phoneInput,
            onValueChange = { phoneInput = it },
            label = { Text("Parent WhatsApp Phone") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = EmeraldPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = courseInput,
            onValueChange = { courseInput = it },
            label = { Text("Target Course") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = EmeraldPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = dateInput,
            onValueChange = { dateInput = it },
            label = { Text("Slot Date & Time") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = EmeraldPrimary
            ),
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (studentNameInput.isNotBlank() && phoneInput.isNotBlank()) {
              viewModel.bookManualAppointment(
                studentName = studentNameInput,
                phone = phoneInput,
                courseName = courseInput,
                slotDate = dateInput,
                slotTime = "10:30 AM",
                type = "FREE_DEMO_CLASS"
              )
              showNewBookingDialog = false
              feedbackNotice = "Slot successfully reserved for $studentNameInput!"
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark)
        ) {
          Text("Confirm Booking")
        }
      },
      dismissButton = {
        TextButton(onClick = { showNewBookingDialog = false }) {
          Text("Cancel", color = TextSecondary)
        }
      },
      containerColor = DarkSurface
    )
  }
}

@Composable
fun AppointmentCard(
  appointment: AppointmentEntity,
  onSendReminder: () -> Unit,
  onReschedule: (String) -> Unit,
  onCancel: () -> Unit,
  onDelete: () -> Unit
) {
  var showMenu by remember { mutableStateOf(false) }

  val statusColor = when (appointment.status) {
    "CONFIRMED" -> EmeraldPrimary
    "REMINDER_SENT" -> GoldAccent
    "CANCELLED" -> CoralError
    else -> NeonMint
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = appointment.studentName,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = appointment.contactPhone,
            color = TextSecondary,
            fontSize = 12.sp
          )
        }

        Surface(
          color = statusColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(12.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
        ) {
          Text(
            text = appointment.status.replace("_", " "),
            color = statusColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Surface(
          color = Color(0xFF1E2C33),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.weight(1f)
        ) {
          Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = NeonMint, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(appointment.slotDate, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
          }
        }

        Surface(
          color = Color(0xFF1E2C33),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.weight(1f)
        ) {
          Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Schedule, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(appointment.appointmentType.replace("_", " "), color = TextPrimary, fontSize = 11.sp)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Action row: Send Reminder, Reschedule, Delete
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = onSendReminder,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonMint),
          border = androidx.compose.foundation.BorderStroke(1.dp, NeonMint.copy(alpha = 0.4f)),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Send Reminder", fontSize = 11.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Box {
            TextButton(
              onClick = { showMenu = true },
              contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
              Text("Actions ▾", color = TextSecondary, fontSize = 12.sp)
            }

            DropdownMenu(
              expanded = showMenu,
              onDismissRequest = { showMenu = false }
            ) {
              DropdownMenuItem(
                text = { Text("Reschedule (Next Sunday 10:30 AM)") },
                onClick = { onReschedule("Next Sunday, 10:30 AM"); showMenu = false }
              )
              DropdownMenuItem(
                text = { Text("Mark Completed") },
                onClick = { onReschedule("COMPLETED"); showMenu = false }
              )
              DropdownMenuItem(
                text = { Text("Cancel Booking", color = CoralError) },
                onClick = { onCancel(); showMenu = false }
              )
            }
          }

          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
          }
        }
      }
    }
  }
}
