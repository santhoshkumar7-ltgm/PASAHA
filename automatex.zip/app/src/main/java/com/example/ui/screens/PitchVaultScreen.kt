package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ObjectionHandler
import com.example.data.PitchScript
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgencyViewModel

@Composable
fun PitchVaultScreen(
  viewModel: AgencyViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val clipboard = remember { context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }
  val scripts = viewModel.strategyRepository.getPitchScripts()
  val objections = viewModel.strategyRepository.getObjectionHandlers()

  var selectedTab by remember { mutableIntStateOf(0) }
  var copiedFeedback by remember { mutableStateOf<String?>(null) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(16.dp)
  ) {
    // Header
    Text(
      text = "Client Pitch & Tech Blueprint",
      color = TextPrimary,
      fontSize = 20.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Proven sales scripts & zero-cost cloud architecture",
      color = TextSecondary,
      fontSize = 12.sp
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Tab Selector
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = DarkSurface,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = EmeraldPrimary
        )
      }
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Outreach Scripts", fontSize = 12.sp, color = if (selectedTab == 0) NeonMint else TextSecondary) }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("Objections", fontSize = 12.sp, color = if (selectedTab == 1) NeonMint else TextSecondary) }
      )
      Tab(
        selected = selectedTab == 2,
        onClick = { selectedTab = 2 },
        text = { Text("n8n / FastAPI Code", fontSize = 12.sp, color = if (selectedTab == 2) NeonMint else TextSecondary) }
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    copiedFeedback?.let { msg ->
      Surface(
        color = Color(0xFF132B20),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 8.dp)
      ) {
        Text(msg, color = NeonMint, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
      }
    }

    when (selectedTab) {
      0 -> {
        // Outreach Scripts
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          contentPadding = PaddingValues(bottom = 16.dp)
        ) {
          items(scripts, key = { it.id }) { script ->
            ScriptCard(
              script = script,
              onCopy = {
                val clip = ClipData.newPlainText(script.title, script.scriptContent)
                clipboard.setPrimaryClip(clip)
                copiedFeedback = "Copied '${script.title}' to clipboard!"
              }
            )
          }
        }
      }
      1 -> {
        // Objections
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          contentPadding = PaddingValues(bottom = 16.dp)
        ) {
          items(objections) { obj ->
            ObjectionCard(objection = obj)
          }
        }
      }
      2 -> {
        // Zero-Cost Architecture & Backend Blueprint
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(12.dp),
          contentPadding = PaddingValues(bottom = 16.dp)
        ) {
          item {
            ZeroCostTechCard(
              onCopy = { codeSnippet ->
                val clip = ClipData.newPlainText("FastAPI Template", codeSnippet)
                clipboard.setPrimaryClip(clip)
                copiedFeedback = "Copied backend code to clipboard!"
              }
            )
          }
        }
      }
    }
  }
}

@Composable
fun ScriptCard(
  script: PitchScript,
  onCopy: () -> Unit
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(script.title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
          Text("${script.channel} • ${script.language}", color = NeonMint, fontSize = 11.sp)
        }

        IconButton(onClick = onCopy) {
          Icon(Icons.Default.ContentCopy, contentDescription = "Copy Script", tint = GoldAccent, modifier = Modifier.size(18.dp))
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Surface(
        color = Color(0xFF0F181D),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1C2C35)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = script.scriptContent,
          color = TextPrimary,
          fontSize = 12.sp,
          lineHeight = 17.sp,
          modifier = Modifier.padding(10.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "💡 Why this converts: ${script.whyItWorks}",
        color = TextSecondary,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
fun ObjectionCard(objection: ObjectionHandler) {
  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.HelpOutline, contentDescription = null, tint = Color(0xFFFF8A80), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(objection.objection, color = Color(0xFFFF8A80), fontSize = 14.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(8.dp))

      Surface(
        color = Color(0xFF13222A),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text("YOUR CO-FOUNDER RESPONSE:", color = GoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(objection.suggestedReply, color = TextPrimary, fontSize = 12.sp, lineHeight = 17.sp)
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Psychology: ${objection.psychologicalTrigger}",
        color = TextSecondary,
        fontSize = 11.sp
      )
    }
  }
}

@Composable
fun ZeroCostTechCard(onCopy: (String) -> Unit) {
  val fastApiSnippet = """
# main.py - AutomateX Zero-Cost FastAPI Webhook Server
from fastapi import FastAPI, Request, BackgroundTasks
import httpx, os

app = FastAPI()

VERIFY_TOKEN = "automatex_secret_token_123"
WHATSAPP_TOKEN = os.getenv("META_WA_TOKEN")
GEMINI_KEY = os.getenv("GEMINI_API_KEY")

@app.get("/webhook")
async def verify(request: Request):
    params = request.query_params
    if params.get("hub.verify_token") == VERIFY_TOKEN:
        return int(params.get("hub.challenge"))
    return "Verification failed", 403

@app.post("/webhook")
async def handle_whatsapp(request: Request, bg_tasks: BackgroundTasks):
    data = await request.json()
    entry = data.get("entry", [{}])[0]
    changes = entry.get("changes", [{}])[0]
    value = changes.get("value", {})
    messages = value.get("messages", [])
    
    if messages:
        sender_phone = messages[0]["from"]
        incoming_text = messages[0]["text"]["body"]
        # Trigger n8n or direct Gemini logic
        bg_tasks.add_task(process_ai_reply, sender_phone, incoming_text)
    return {"status": "ok"}
  """.trimIndent()

  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Zero-Cost Production Stack", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = { onCopy(fastApiSnippet) }) {
          Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = NeonMint, modifier = Modifier.size(18.dp))
        }
      }

      Text(
        text = "1. Meta WhatsApp Cloud API: 1,000 free conversations/month\n2. Google Gemini API: Free / fraction-of-paisa per call\n3. n8n / FastAPI: Runs on a ₹400-₹800/mo VPS or free Render instance\n4. Zero software licenses needed to start!",
        color = TextSecondary,
        fontSize = 12.sp,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(10.dp))

      Surface(
        color = Color(0xFF091216),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B2C33)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = fastApiSnippet,
          fontFamily = FontFamily.Monospace,
          color = NeonMint,
          fontSize = 11.sp,
          lineHeight = 15.sp,
          modifier = Modifier.padding(10.dp)
        )
      }
    }
  }
}
