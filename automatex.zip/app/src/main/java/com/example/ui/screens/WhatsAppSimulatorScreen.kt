package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AiMessage
import com.example.data.MessageSender
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WhatsAppBubbleIncoming
import com.example.ui.theme.WhatsAppBubbleOutgoing
import com.example.ui.theme.WhatsAppChatBg
import com.example.ui.theme.WhatsAppDoubleTickBlue
import com.example.ui.theme.WhatsAppGreenHeader
import com.example.viewmodel.AgencyViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppSimulatorScreen(
  viewModel: AgencyViewModel,
  modifier: Modifier = Modifier
) {
  val messages by viewModel.messages.collectAsState()
  val isTyping by viewModel.isTyping.collectAsState()
  val lastAiResult by viewModel.lastAiResult.collectAsState()
  val humanHandoffActive by viewModel.humanHandoffActive.collectAsState()

  var inputText by remember { mutableStateOf("") }
  var showBrainInspector by remember { mutableStateOf(false) }
  var showDemoGuideDialog by remember { mutableStateOf(false) }

  val listState = rememberLazyListState()

  LaunchedEffect(messages.size, isTyping) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val quickPrompts = listOf(
    "💰 Fees evvalavu? (Tamil)",
    "🎯 NEET Repeater Batches",
    "📅 Book Free Demo Class",
    "🏠 Hostel & Food Facilities",
    "👨‍⚕️ I have a fee discount dispute"
  )

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(WhatsAppChatBg)
  ) {
    // WhatsApp Header Bar
    Surface(
      color = WhatsAppGreenHeader,
      tonalElevation = 4.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Academy Profile Picture
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(Color(0xFF075E54)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.School,
            contentDescription = "Academy Logo",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Title and Status
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Apex NEET Academy",
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.Check,
              contentDescription = "Verified Official Account",
              tint = NeonMint,
              modifier = Modifier.size(14.dp)
            )
          }
          Text(
            text = if (isTyping) "typing..." else if (humanHandoffActive) "Agent Sridhar (Human Support)" else "Online • AI Admissions Bot",
            color = if (isTyping) NeonMint else Color(0xFFD4EBE7),
            fontSize = 12.sp
          )
        }

        // Actions
        IconButton(
          onClick = { showBrainInspector = true },
          modifier = Modifier.testTag("toggle_brain_inspector")
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = "AI Brain Inspector",
            tint = GoldAccent
          )
        }

        IconButton(
          onClick = { showDemoGuideDialog = true },
          modifier = Modifier.testTag("toggle_info_dialog")
        ) {
          Icon(
            imageVector = Icons.Default.Info,
            contentDescription = "Demo Pitch Guide",
            tint = Color.White
          )
        }

        IconButton(
          onClick = { viewModel.resetChat() },
          modifier = Modifier.testTag("reset_chat_button")
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "Reset Conversation",
            tint = Color.White
          )
        }
      }
    }

    // Encryption Note
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp, bottom = 4.dp),
      contentAlignment = Alignment.Center
    ) {
      Surface(
        color = Color(0xFF182229),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.padding(horizontal = 24.dp)
      ) {
        Text(
          text = "🔒 Live Demo: Powered by AutomateX AI Agent • 24/7 Bilingual WhatsApp Cloud API",
          color = Color(0xFFFFD279),
          fontSize = 11.sp,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
      }
    }

    // Human Handoff Notification Banner
    if (humanHandoffActive) {
      Surface(
        color = Color(0xFF332015),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(8.dp)
      ) {
        Row(
          modifier = Modifier.padding(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Human Takeover Active",
            tint = GoldAccent,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Human Counselor Intervened: Automated bot paused for sensitive inquiry.",
            color = Color(0xFFFFE0B2),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }
    }

    // Message Thread
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
      contentPadding = PaddingValues(vertical = 8.dp)
    ) {
      items(messages, key = { it.id }) { message ->
        ChatMessageBubble(message = message)
      }

      if (isTyping) {
        item {
          TypingIndicatorBubble()
        }
      }
    }

    // Quick Tap Prompts for Client Demos
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .background(Color(0xFF111B21))
        .padding(vertical = 6.dp),
      contentPadding = PaddingValues(horizontal = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(quickPrompts) { prompt ->
        Surface(
          color = Color(0xFF1F2C34),
          shape = RoundedCornerShape(16.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A3942)),
          modifier = Modifier
            .clickable {
              val promptClean = prompt.substringAfter(" ").trim()
              viewModel.sendMessage(promptClean)
            }
            .testTag("quick_prompt_${prompt.take(5)}")
        ) {
          Text(
            text = prompt,
            color = NeonMint,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
          )
        }
      }
    }

    // Input Bar
    Surface(
      color = Color(0xFF1F2C34),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = inputText,
          onValueChange = { inputText = it },
          placeholder = { Text("Ask fees, timings, or demo...", color = TextMuted, fontSize = 14.sp) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedContainerColor = Color(0xFF2A3942),
            unfocusedContainerColor = Color(0xFF2A3942),
            focusedBorderColor = EmeraldPrimary,
            unfocusedBorderColor = Color.Transparent
          ),
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("whatsapp_message_input"),
          maxLines = 3
        )

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(EmeraldDark)
            .clickable {
              if (inputText.isNotBlank()) {
                viewModel.sendMessage(inputText)
                inputText = ""
              }
            }
            .testTag("whatsapp_send_button"),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send Message",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }

  // AI Brain Inspector Bottom Sheet
  if (showBrainInspector) {
    ModalBottomSheet(
      onDismissRequest = { showBrainInspector = false },
      sheetState = rememberModalBottomSheetState(),
      containerColor = DarkSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = GoldAccent,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "AI Brain Inspector (n8n & Gemini Engine)",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        lastAiResult?.let { result ->
          Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "DETECTED INTENT",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = result.detectedIntent,
                color = NeonMint,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
              )

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = "CONFIDENCE SCORE",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${(result.confidence * 100).toInt()}% • Natural Language Matching",
                color = TextPrimary,
                fontSize = 14.sp
              )

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = "REASONING & ROUTING",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = result.reasoningSnippet,
                color = TextSecondary,
                fontSize = 13.sp
              )

              if (result.extractedLead != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                  color = Color(0xFF0F291E),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                      text = "✓ LEAD AUTO-SYNCED TO CRM",
                      color = EmeraldPrimary,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold
                    )
                    Text(
                      text = "Student: ${result.extractedLead.studentName} | Status: ${result.extractedLead.status}",
                      color = TextPrimary,
                      fontSize = 12.sp
                    )
                  }
                }
              }
            }
          }
        } ?: run {
          Text(
            text = "Send a message in the chat above to see how our prompt parsing, lead extraction, and intent classification operate live.",
            color = TextSecondary,
            fontSize = 14.sp
          )
        }

        Spacer(modifier = Modifier.height(20.dp))
      }
    }
  }

  // Demo Guide Dialog
  if (showDemoGuideDialog) {
    AlertDialog(
      onDismissRequest = { showDemoGuideDialog = false },
      title = {
        Text("Client Demo Strategy (Apex Academy)", color = TextPrimary, fontWeight = FontWeight.Bold)
      },
      text = {
        Column {
          Text(
            "How to present this live to an Indian coaching centre director:",
            color = TextSecondary,
            fontSize = 14.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            "1. Hand your phone to the owner and say: 'Try typing a fee question in Tamil or English.'",
            color = TextPrimary,
            fontSize = 13.sp
          )
          Text(
            "2. Tap 'Book Free Demo Class' to show how a student lead is captured and scheduled within 10 seconds.",
            color = TextPrimary,
            fontSize = 13.sp
          )
          Text(
            "3. Switch to the 'Leads CRM' tab to show them their new student record waiting in real time.",
            color = TextPrimary,
            fontSize = 13.sp
          )
        }
      },
      confirmButton = {
        TextButton(onClick = { showDemoGuideDialog = false }) {
          Text("Got It", color = EmeraldPrimary)
        }
      },
      containerColor = DarkSurface
    )
  }
}

@Composable
fun ChatMessageBubble(message: AiMessage) {
  val isOutgoing = message.sender == MessageSender.USER
  val bubbleColor = if (isOutgoing) WhatsAppBubbleOutgoing else WhatsAppBubbleIncoming
  val alignArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start

  val timeFormatter = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
  val timeStr = remember(message.timestamp) { timeFormatter.format(Date(message.timestamp)) }

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = alignArrangement
  ) {
    Surface(
      color = bubbleColor,
      shape = RoundedCornerShape(
        topStart = 12.dp,
        topEnd = 12.dp,
        bottomStart = if (isOutgoing) 12.dp else 2.dp,
        bottomEnd = if (isOutgoing) 2.dp else 12.dp
      ),
      modifier = Modifier.widthIn(max = 300.dp)
    ) {
      Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
        if (message.sender == MessageSender.HUMAN_AGENT) {
          Text(
            text = "👨‍💼 Senior Admissions Counselor",
            color = GoldAccent,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 2.dp)
          )
        }

        Text(
          text = message.text,
          color = TextPrimary,
          fontSize = 14.sp,
          lineHeight = 19.sp
        )

        Row(
          modifier = Modifier
            .align(Alignment.End)
            .padding(top = 2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = timeStr,
            color = TextMuted,
            fontSize = 10.sp
          )
          if (isOutgoing) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.Default.DoneAll,
              contentDescription = "Read",
              tint = WhatsAppDoubleTickBlue,
              modifier = Modifier.size(14.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun TypingIndicatorBubble() {
  Surface(
    color = WhatsAppBubbleIncoming,
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.padding(start = 4.dp)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(6.dp)
          .clip(CircleShape)
          .background(NeonMint)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Box(
        modifier = Modifier
          .size(6.dp)
          .clip(CircleShape)
          .background(NeonMint.copy(alpha = 0.6f))
      )
      Spacer(modifier = Modifier.width(4.dp))
      Box(
        modifier = Modifier
          .size(6.dp)
          .clip(CircleShape)
          .background(NeonMint.copy(alpha = 0.3f))
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "AI is composing reply...",
        color = TextSecondary,
        fontSize = 12.sp
      )
    }
  }
}
