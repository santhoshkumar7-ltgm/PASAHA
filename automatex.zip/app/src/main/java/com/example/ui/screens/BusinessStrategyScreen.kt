package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoadmapStage
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgencyViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun BusinessStrategyScreen(
  viewModel: AgencyViewModel,
  modifier: Modifier = Modifier
) {
  val calcState by viewModel.calcState.collectAsState()
  val stages = viewModel.strategyRepository.getRoadmapStages()

  val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("en", "IN")) }

  var clientCountSlider by remember { mutableStateOf(calcState.clientCount.toFloat()) }
  var setupFeeSlider by remember { mutableStateOf(calcState.setupFee.toFloat()) }
  var retainerSlider by remember { mutableStateOf(calcState.monthlyRetainer.toFloat()) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBackground)
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(bottom = 24.dp)
  ) {
    // Header
    item {
      Column {
        Text(
          text = "Unit Economics & Profit Blueprint",
          color = TextPrimary,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "Phase 1: Zero-Investment Business Engine in India",
          color = TextSecondary,
          fontSize = 12.sp
        )
      }
    }

    // Economics Summary Ribbon
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1F24)),
        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("ESTIMATED MONTHLY PROFIT", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text(
                text = currencyFormat.format(calcState.netMonthlyProfit),
                color = NeonMint,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Surface(
              color = EmeraldPrimary.copy(alpha = 0.15f),
              shape = RoundedCornerShape(16.dp)
            ) {
              Text(
                text = "${calcState.profitMarginPercent}% Margin",
                color = EmeraldPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("Immediate Upfront Cash", color = TextMuted, fontSize = 11.sp)
              Text(currencyFormat.format(calcState.totalUpfrontCash), color = GoldAccent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Column {
              Text("Monthly Recurring (MRR)", color = TextMuted, fontSize = 11.sp)
              Text(currencyFormat.format(calcState.monthlyRecurringRevenue), color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Column {
              Text("Est. Cloud Cost", color = TextMuted, fontSize = 11.sp)
              Text(currencyFormat.format(calcState.estimatedMonthlyExpense), color = Color(0xFFFF8A80), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }

    // Interactive Sliders
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("INTERACTIVE REVENUE SIMULATOR", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

          Spacer(modifier = Modifier.height(12.dp))

          // Slider 1: Clients
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Active Business Clients", color = TextPrimary, fontSize = 13.sp)
            Text("${clientCountSlider.toInt()} Clients", color = NeonMint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = clientCountSlider,
            onValueChange = {
              clientCountSlider = it
              viewModel.updateCalculator(it.toInt(), setupFeeSlider.toInt(), retainerSlider.toInt())
            },
            valueRange = 1f..30f,
            colors = SliderDefaults.colors(thumbColor = NeonMint, activeTrackColor = EmeraldPrimary),
            modifier = Modifier.testTag("slider_clients")
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Slider 2: Setup Fee
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Upfront Setup Fee per Client", color = TextPrimary, fontSize = 13.sp)
            Text(currencyFormat.format(setupFeeSlider.toInt()), color = GoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = setupFeeSlider,
            onValueChange = {
              setupFeeSlider = it
              viewModel.updateCalculator(clientCountSlider.toInt(), it.toInt(), retainerSlider.toInt())
            },
            valueRange = 10000f..50000f,
            steps = 7,
            colors = SliderDefaults.colors(thumbColor = GoldAccent, activeTrackColor = GoldAccent.copy(alpha = 0.7f)),
            modifier = Modifier.testTag("slider_setup_fee")
          )

          Spacer(modifier = Modifier.height(8.dp))

          // Slider 3: Monthly AMC / Retainer
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Monthly Maintenance Retainer", color = TextPrimary, fontSize = 13.sp)
            Text("${currencyFormat.format(retainerSlider.toInt())} / mo", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = retainerSlider,
            onValueChange = {
              retainerSlider = it
              viewModel.updateCalculator(clientCountSlider.toInt(), setupFeeSlider.toInt(), it.toInt())
            },
            valueRange = 3000f..20000f,
            steps = 16,
            colors = SliderDefaults.colors(thumbColor = TextPrimary, activeTrackColor = NeonMint),
            modifier = Modifier.testTag("slider_retainer")
          )
        }
      }
    }

    // Beginner Business Explanation Card
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text("💡 FOUNDER LESSON 1: UNIT ECONOMICS", color = GoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "• Revenue = Total money collected from clients (Setup Fee + Monthly Retainer).\n• Expenses = Money spent to run the service. With WhatsApp Cloud API (1,000 free conversations/month) + Gemini Flash API (fraction of a paisa) + a simple ₹800 VPS, your expenses are under 8%.\n• Net Profit = Revenue minus Expenses. You keep over 92% in your bank account!",
            color = TextSecondary,
            fontSize = 12.sp,
            lineHeight = 18.sp
          )
        }
      }
    }

    // Roadmap Title
    item {
      Text(
        text = "5-PHASE ROADMAP TO ₹50 CRORE MONTHLY PROFIT",
        color = TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    // Roadmap Accordion Items
    items(stages) { stage ->
      RoadmapStageCard(stage = stage)
    }
  }
}

@Composable
fun RoadmapStageCard(stage: RoadmapStage) {
  var isExpanded by remember { mutableStateOf(stage.stageNumber == 1) }

  Card(
    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
    shape = RoundedCornerShape(12.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable { isExpanded = !isExpanded },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(if (stage.stageNumber == 1) EmeraldDark else Color(0xFF1E2D34)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "${stage.stageNumber}",
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Text(stage.title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
              "Target: ${stage.monthlyProfitTarget} • ${stage.targetClients}",
              color = NeonMint,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }

        Icon(
          imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
          contentDescription = null,
          tint = TextSecondary
        )
      }

      AnimatedVisibility(visible = isExpanded) {
        Column(modifier = Modifier.padding(top = 12.dp)) {
          Surface(
            color = Color(0xFF162329),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("STRATEGIC FOCUS:", color = GoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              Text(stage.primaryFocus, color = TextSecondary, fontSize = 12.sp)
              Spacer(modifier = Modifier.height(6.dp))
              Text("TEAM STRUCTURE: ${stage.teamSize}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text("KEY MILESTONES TO UNLOCK:", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          stage.keyMilestones.forEach { milestone ->
            Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(milestone, color = TextSecondary, fontSize = 12.sp)
            }
          }
        }
      }
    }
  }
}
