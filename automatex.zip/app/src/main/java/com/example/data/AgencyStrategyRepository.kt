package com.example.data

data class RoadmapStage(
  val stageNumber: Int,
  val title: String,
  val monthlyRevenueTarget: String,
  val monthlyProfitTarget: String,
  val targetClients: String,
  val primaryFocus: String,
  val teamSize: String,
  val keyMilestones: List<String>
)

data class PitchScript(
  val id: String,
  val title: String,
  val channel: String,
  val targetPersona: String,
  val language: String,
  val scriptContent: String,
  val whyItWorks: String
)

data class ObjectionHandler(
  val objection: String,
  val suggestedReply: String,
  val psychologicalTrigger: String
)

class AgencyStrategyRepository {

  fun getRoadmapStages(): List<RoadmapStage> = listOf(
    RoadmapStage(
      stageNumber = 1,
      title = "Ground Zero & First Paying Customer",
      monthlyRevenueTarget = "₹1,00,000 / mo",
      monthlyProfitTarget = "₹92,000 / mo",
      targetClients = "3 to 4 Coaching Institutes",
      primaryFocus = "Manual outreach in local city (Chennai / Coimbatore / Madurai / Bangalore). Build live client demo on your phone, offer 7-day risk-free pilot.",
      teamSize = "Solo Founder (You)",
      keyMilestones = listOf(
        "Deploy live WhatsApp bot for 1 coaching institute",
        "Charge ₹25,000 setup fee + ₹5,000 monthly AMC",
        "Capture minimum 50 student leads in week 1 to prove undeniable ROI"
      )
    ),
    RoadmapStage(
      stageNumber = 2,
      title = "Agency Growth & Productization",
      monthlyRevenueTarget = "₹10,00,000 / mo",
      monthlyProfitTarget = "₹8,50,000 / mo",
      targetClients = "25 to 30 Clients (Coaching & Hospitals)",
      primaryFocus = "Standardize n8n + FastAPI pipeline templates. Upsell AI voice appointment callers and automatic lead CRM dashboards.",
      teamSize = "Founder + 1 Junior Developer + 1 Sales Intern",
      keyMilestones = listOf(
        "Automate client onboarding via reusable configuration templates",
        "Achieve ₹2.5L recurring monthly retainer revenue (MRR)",
        "Zero customer churn by providing weekly lead audit reports"
      )
    ),
    RoadmapStage(
      stageNumber = 3,
      title = "Multi-Tenant SaaS Conversion",
      monthlyRevenueTarget = "₹1,00,00,000 / mo",
      monthlyProfitTarget = "₹80,00,000 / mo",
      targetClients = "200+ Businesses Across South India",
      primaryFocus = "Transition from service agency to self-serve SaaS platform where coaching centres configure their own bot in 15 minutes.",
      teamSize = "6 to 8 Core Members (Tech, Sales, Support)",
      keyMilestones = listOf(
        "Self-serve client web portal with WhatsApp QR code link",
        "Integrate Razorpay automated monthly subscription billing",
        "Direct partnership with Coaching Association networks"
      )
    ),
    RoadmapStage(
      stageNumber = 4,
      title = "Pan-India Expansion",
      monthlyRevenueTarget = "₹10,00,00,000 / mo",
      monthlyProfitTarget = "₹7,80,00,000 / mo",
      targetClients = "1,500+ Institutions, Clinics & Real Estate Brands",
      primaryFocus = "Expand into North & West India (Delhi-NCR, Kota, Pune, Hyderabad) with native Hindi & Telugu voice AI support.",
      teamSize = "30+ Team Members",
      keyMilestones = listOf(
        "Enterprise deals with 10+ major coaching chains (Allen/Aakash franchise levels)",
        "AI Outbound Voice Calling Engine replacing human telecallers",
        "₹8 Cr+ recurring MRR base"
      )
    ),
    RoadmapStage(
      stageNumber = 5,
      title = "Global Enterprise & ₹50 Cr Monthly Profit",
      monthlyRevenueTarget = "₹65,00,00,000 / mo",
      monthlyProfitTarget = "₹50,00,00,000 / mo",
      targetClients = "5,000+ Global Accounts (India, Middle East, Southeast Asia)",
      primaryFocus = "Omnichannel Autonomous AI Workforce for Customer Operations across WhatsApp, Instagram DM, Phone Calls, and Web.",
      teamSize = "120+ International Team",
      keyMilestones = listOf(
        "Proprietary fine-tuned multimodal models for industry verticals",
        "Global leadership in emerging market SMB automation",
        "Sustainable ₹50 Crore monthly net profit generation"
      )
    )
  )

  fun getPitchScripts(): List<PitchScript> = listOf(
    PitchScript(
      id = "pitch_wa_tamil",
      title = "Coaching Institute WhatsApp Outreach (Tamil & English)",
      channel = "WhatsApp Message to Institute Director",
      targetPersona = "Academy Owner / Director",
      language = "Bilingual (Tanglish & English)",
      scriptContent = """
Vanakkam Sir 🙏
My name is [Your Name], founder at AutomateX.

I noticed that [Institute Name] receives dozens of student admission queries daily on your WhatsApp number.

Did you know that over 40% of parents message after 7:00 PM or on Sundays when staff are unavailable? Most of these leads end up enrolling with competitors who respond within 2 minutes.

We built an AI WhatsApp Admissions Assistant specifically for NEET/JEE coaching centres:
1. Answers fee, hostel & batch questions 24/7 in English & தமிழ்
2. Books free demo classes automatically
3. Sends instant lead alerts directly to your personal phone

We would love to set up a 100% free 7-day live trial for your academy—zero upfront cost. 

Can I share a 1-minute video demo of how it works for [Institute Name]?
      """.trimIndent(),
      whyItWorks = "Highlights immediate lost revenue (night/weekend leads) and removes all friction by offering a 7-day risk-free pilot."
    ),
    PitchScript(
      id = "pitch_in_person",
      title = "In-Person 3-Minute Meeting Script",
      channel = "Direct Academy Visit",
      targetPersona = "Center Head / Senior Counselor",
      language = "Direct & Confident English",
      scriptContent = """
"Good morning, Sir. I’m not here to sell you a software. I’m here to show you how you can stop losing 15-20 student admissions every single month.

Right now, your counselors spend 70% of their workday answering the exact same 4 questions on WhatsApp: 'What is the fee?', 'What are the batch timings?', 'Is hostel available?', and 'Where is the branch?'

Because they are busy answering these repetitive questions, they don't have enough time to follow up with high-intent parents.

Watch this: (Pull out AutomateX phone demo)
Pretend I'm a 12th standard parent asking: 'What is the fee for the repeater batch and do you have hostel?'
Look at the screen—in 3 seconds, the AI provided the exact fee structure, explained the scholarship criteria, collected the student's name, and confirmed a Saturday demo class.

Our system runs 24 hours a day, never takes leave, and automatically pushes every student's phone number into this CRM dashboard.

Let’s deploy this on your test number today. If you don't get at least 15 new student admissions this month, you don't pay a single rupee."
      """.trimIndent(),
      whyItWorks = "Bypasses technical jargon, demonstrates the live Android prototype immediately, and offers a performance guarantee."
    )
  )

  fun getObjectionHandlers(): List<ObjectionHandler> = listOf(
    ObjectionHandler(
      objection = "\"My front office staff already handles all WhatsApp messages.\"",
      suggestedReply = "That's great, Sir! But what happens at 9:30 PM on Sunday night when a father is researching NEET coaching for his daughter? Parents message 3 academies simultaneously. Whoever answers first books the demo class. Our AI responds in 5 seconds while your staff is sleeping, and hands the warm lead to your team Monday morning.",
      psychologicalTrigger = "Fear of missing out to competing academies during off-hours."
    ),
    ObjectionHandler(
      objection = "\"Is WhatsApp automation legal or will our business number get banned?\"",
      suggestedReply = "We strictly use Meta's official WhatsApp Business Cloud API with your verified business green tick credentials. We do not use illegal bulk spam software. Meta officially approves and protects your number.",
      psychologicalTrigger = "Trust and compliance assurance with official Meta APIs."
    ),
    ObjectionHandler(
      objection = "\"We don't have budget for expensive AI software right now.\"",
      suggestedReply = "Sir, one single student enrollment in your NEET repeater batch brings you ₹65,000. Our entire system costs only ₹5,000 per month. If this AI brings you even ONE extra admission in 3 months, it has paid for itself 4 times over. It is not an expense—it is an admission magnet.",
      psychologicalTrigger = "High ROI comparison against single student lifetime value."
    )
  )
}
