package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AppointmentDao
import com.example.data.dao.LeadDao
import com.example.data.model.AppointmentEntity
import com.example.data.model.LeadEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [LeadEntity::class, AppointmentEntity::class],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun leadDao(): LeadDao
  abstract fun appointmentDao(): AppointmentDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "automatex_database"
        )
        .addCallback(DatabaseCallback(scope))
        .build()
        INSTANCE = instance
        instance
      }
    }

    private class DatabaseCallback(
      private val scope: CoroutineScope
    ) : Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database.leadDao(), database.appointmentDao())
          }
        }
      }

      suspend fun populateInitialData(leadDao: LeadDao, appointmentDao: AppointmentDao) {
        val initialLeads = listOf(
          LeadEntity(
            studentName = "Karthik Subramanian",
            parentPhone = "+91 98401 23456",
            targetCourse = "NEET 1-Year Repeater Batch",
            inquirySummary = "Enquired about hostel facility, fee concession for 90%+ in 12th, and weekend test schedule.",
            score = "HOT",
            status = "DEMO_SCHEDULED",
            timestamp = System.currentTimeMillis() - 3600000 * 2,
            clientSource = "Apex NEET Academy"
          ),
          LeadEntity(
            studentName = "Ananya Raman",
            parentPhone = "+91 94440 87654",
            targetCourse = "Class 11 Foundation (CBSE + JEE)",
            inquirySummary = "Asked in Tamil regarding evening batch timings and trial class.",
            score = "HOT",
            status = "NEW",
            timestamp = System.currentTimeMillis() - 3600000 * 5,
            clientSource = "Apex NEET Academy"
          ),
          LeadEntity(
            studentName = "Mohamed Riyas",
            parentPhone = "+91 97900 11223",
            targetCourse = "NEET Crash Course 2027",
            inquirySummary = "Requested fee breakdown and discount for single parent.",
            score = "WARM",
            status = "FOLLOW_UP",
            timestamp = System.currentTimeMillis() - 3600000 * 24,
            clientSource = "Apex NEET Academy"
          )
        )
        leadDao.insertAll(initialLeads)

        val initialAppointments = listOf(
          AppointmentEntity(
            leadId = 1L,
            studentName = "Karthik Subramanian",
            contactPhone = "+91 98401 23456",
            courseName = "NEET Repeater Demo Class",
            slotDate = "Tomorrow, 10:30 AM",
            slotTime = "10:30 AM",
            appointmentType = "FREE_DEMO_CLASS",
            status = "CONFIRMED",
            reminderScheduled = true
          ),
          AppointmentEntity(
            leadId = 2L,
            studentName = "Ananya Raman",
            contactPhone = "+91 94440 87654",
            courseName = "Foundation Batch Counselling",
            slotDate = "Saturday, 04:00 PM",
            slotTime = "04:00 PM",
            appointmentType = "CAREER_COUNSELLING",
            status = "REMINDER_SENT",
            reminderScheduled = true
          )
        )
        appointmentDao.insertAll(initialAppointments)
      }
    }
  }
}
