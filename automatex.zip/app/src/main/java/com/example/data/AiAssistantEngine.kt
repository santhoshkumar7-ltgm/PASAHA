package com.example.data

import com.example.data.model.AppointmentEntity
import com.example.data.model.LeadEntity
import java.util.regex.Pattern

data class AiMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val sender: MessageSender,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val isAudio: Boolean = false,
  val audioDurationSec: Int = 0,
  val isHandoffAlert: Boolean = false
)

enum class MessageSender {
  USER,
  BOT,
  HUMAN_AGENT,
  SYSTEM
}

data class AiProcessingResult(
  val replyText: String,
  val detectedIntent: String,
  val extractedLead: LeadEntity? = null,
  val bookedAppointment: AppointmentEntity? = null,
  val isHumanHandoff: Boolean = false,
  val reasoningSnippet: String = "",
  val confidence: Float = 0.95f
)

class AiAssistantEngine {

  private var studentName: String? = null
  private var studentPhone: String? = null
  private var targetCourse: String? = null

  fun processIncomingMessage(input: String): AiProcessingResult {
    val clean = input.trim()
    val lower = clean.lowercase()

    // 1. Check for Phone Number in text
    val phoneMatcher = Pattern.compile("(\\+91[\\-\\s]?)?[6-9]\\d{9}").matcher(clean)
    if (phoneMatcher.find()) {
      studentPhone = phoneMatcher.group()
    }

    // 2. Human Handoff triggers
    val humanTriggers = listOf("refund", "complaint", "speak to principal", "custom discount", "fraud", "manager", "dispute", "escalate")
    if (humanTriggers.any { lower.contains(it) }) {
      return AiProcessingResult(
        replyText = "I understand this requires special attention. I have transferred this enquiry to our Senior Admissions Counselor (Mr. Sridhar, +91 94441 55667). They will call you directly within 15 minutes.",
        detectedIntent = "HUMAN_HANDOFF_ESCALATION",
        isHumanHandoff = true,
        reasoningSnippet = "Complex inquiry / escalation keyword identified. Routed away from automated bot to human staff.",
        confidence = 0.99f
      )
    }

    // 3. Demo Class / Appointment Booking Intent
    if (lower.contains("demo") || lower.contains("trial") || lower.contains("book") || lower.contains("slot") || lower.contains("counselling") || lower.contains("visit")) {
      val bookedAppt = AppointmentEntity(
        studentName = studentName ?: "New Applicant",
        contactPhone = studentPhone ?: "+91 98400 00000",
        courseName = targetCourse ?: "NEET & JEE Foundation",
        slotDate = "This Saturday, 10:30 AM",
        slotTime = "10:30 AM",
        appointmentType = "FREE_DEMO_CLASS",
        status = "CONFIRMED"
      )

      val lead = LeadEntity(
        studentName = studentName ?: "New Demo Lead",
        parentPhone = studentPhone ?: "+91 98400 00000",
        targetCourse = targetCourse ?: "Demo Session",
        inquirySummary = "Student booked a Free Demo Session for Saturday 10:30 AM via WhatsApp Assistant.",
        score = "HOT",
        status = "DEMO_SCHEDULED"
      )

      return AiProcessingResult(
        replyText = "Great decision! 🎯 I have reserved your seat for the Free 2-Day Interactive Demo Class on Saturday at 10:30 AM (Apex Academy, Anna Nagar Branch).\n\nDetails confirmed for:\n• Slot: Saturday 10:30 AM\n• Topic: NEET High-Yield Physics & Biology Masterclass\n• Venue: Hall 2, Apex Academy\n\nWould you like me to send location directions via Google Maps?",
        detectedIntent = "APPOINTMENT_DEMO_BOOKING",
        extractedLead = lead,
        bookedAppointment = bookedAppt,
        reasoningSnippet = "Captured high-intent user requesting demo class. Slot allocated and synced into CRM table.",
        confidence = 0.98f
      )
    }

    // 4. Tamil / Tanglish Queries: "Fees evvalavu?", "Enna batch irukku?", "Hostel irukka?"
    if (lower.contains("fees evvalavu") || lower.contains("fee evvalavu") || lower.contains("kattanam") || lower.contains("evlo fee") || lower.contains("evalo")) {
      return AiProcessingResult(
        replyText = "Vanakkam! 🙏 Apex NEET Academy-il fee details:\n\n1. NEET Repeater Batch: ₹65,000 / year (Books + 80+ Mock Tests included)\n2. JEE Main + Advanced: ₹75,000 / year\n3. Class 11-12 Integrated: ₹50,000 / year\n\n10th/12th marks-la 90%+ edutha ₹15,000 varai scholarship irukku! Unga student name and phone number solreengala? Free demo class book panniduvom.",
        detectedIntent = "FEE_INQUIRY_TAMIL",
        reasoningSnippet = "Tamil/Tanglish query detected for fee structure. Provided transparent pricing with scholarship incentive to capture lead.",
        confidence = 0.97f
      )
    }

    if (lower.contains("hostel") || lower.contains("stay") || lower.contains("accommodation")) {
      return AiProcessingResult(
        replyText = "Yes, Apex Academy provides safe, separate AC & Non-AC hostels for boys and girls with:\n• Hygienic South Indian home-cooked meals 🍛\n• Dedicated evening study hours under faculty supervision\n• 24/7 CCTV security & biometric entry\n\nHostel fee is ₹6,500/month (including food & accommodation). Would you like photos or a campus visit?",
        detectedIntent = "HOSTEL_INQUIRY",
        reasoningSnippet = "Answered accommodation details with reassurance on security and monthly pricing.",
        confidence = 0.94f
      )
    }

    // 5. English Fee Query
    if (lower.contains("fee") || lower.contains("cost") || lower.contains("price") || lower.contains("charges")) {
      return AiProcessingResult(
        replyText = "Here is our transparent fee structure at Apex NEET Academy:\n\n• NEET 1-Year Repeater Batch: ₹65,000 (includes printed modules & test series)\n• JEE Main & Advanced: ₹75,000\n• Class 11 & 12 Evening Batch: ₹50,000/year\n\n⭐ Up to 40% Merit Scholarships are available based on our Diagnostic Test.\n\nMay I know the student's name and present class to suggest the best batch?",
        detectedIntent = "FEE_STRUCTURE_INQUIRY",
        reasoningSnippet = "Structured fee quote with lead capture question.",
        confidence = 0.96f
      )
    }

    // 6. Timing / Batches
    if (lower.contains("timing") || lower.contains("batch") || lower.contains("schedule") || lower.contains("time")) {
      return AiProcessingResult(
        replyText = "We offer flexible batches tailored for school students and repeaters:\n\n• Morning Batch: 6:30 AM – 8:30 AM (Mon-Fri)\n• Evening Batch: 5:30 PM – 8:30 PM (Mon-Fri)\n• Weekend Intensive: 9:00 AM – 4:30 PM (Sat & Sun)\n• Full-Time Repeater Batch: 9:00 AM – 4:00 PM (Mon-Sat)\n\nWhich batch suits your schedule best?",
        detectedIntent = "BATCH_TIMINGS_INQUIRY",
        reasoningSnippet = "Detailed batch options shared to help user qualify their availability.",
        confidence = 0.95f
      )
    }

    // 7. General Lead Capture / Name detection
    if (lower.contains("my name is") || lower.contains("i am") || lower.contains("this is") || (clean.length < 30 && clean.split(" ").size in 2..3 && !lower.contains("how") && !lower.contains("what"))) {
      studentName = clean.replace("my name is", "", true).replace("i am", "", true).trim().capitalizeWords()
      val lead = LeadEntity(
        studentName = studentName ?: "Prospective Student",
        parentPhone = studentPhone ?: "+91 98401 99887",
        targetCourse = targetCourse ?: "NEET 2027",
        inquirySummary = "Student identified themselves as $studentName and requested course curriculum information.",
        score = "WARM",
        status = "NEW"
      )

      return AiProcessingResult(
        replyText = "Pleasure to connect with you, $studentName! 🎓 Are you looking to crack NEET, JEE, or preparing for Class 11/12 Board Exams? Let me know, and I'll share our syllabus booklet and previous year result statistics.",
        detectedIntent = "STUDENT_NAME_IDENTIFIED",
        extractedLead = lead,
        reasoningSnippet = "Parsed user name ($studentName) and stored lead in CRM pipeline.",
        confidence = 0.92f
      )
    }

    // Default polite assistant response
    return AiProcessingResult(
      replyText = "Hello! Welcome to Apex NEET & JEE Academy WhatsApp Support. 🌟\n\nHow can I help you today?\n1. Course Details & Eligibility\n2. Fee Structure & Scholarship Test\n3. Batch Timings & Hostel Facility\n4. Book a Free Trial Demo Class\n\nYou can ask in English or தமிழ்!",
      detectedIntent = "GREETING_AND_NAVIGATION",
      reasoningSnippet = "Provided warm bilingual welcome menu with instant action suggestions.",
      confidence = 0.90f
    )
  }

  private fun String.capitalizeWords(): String =
    split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
}
