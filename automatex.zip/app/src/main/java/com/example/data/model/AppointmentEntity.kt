package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "appointments")
data class AppointmentEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val leadId: Long? = null,
  val studentName: String,
  val contactPhone: String,
  val courseName: String,
  val slotDate: String,
  val slotTime: String,
  val appointmentType: String, // "FREE_DEMO_CLASS", "CAREER_COUNSELLING", "FACULTY_MEET"
  val status: String, // "CONFIRMED", "REMINDER_SENT", "COMPLETED", "CANCELLED"
  val reminderScheduled: Boolean = true,
  val createdAt: Long = System.currentTimeMillis()
)
