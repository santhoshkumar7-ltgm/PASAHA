package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.LeadEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LeadDao {
  @Query("SELECT * FROM leads ORDER BY timestamp DESC")
  fun getAllLeads(): Flow<List<LeadEntity>>

  @Query("SELECT * FROM leads WHERE status = :status ORDER BY timestamp DESC")
  fun getLeadsByStatus(status: String): Flow<List<LeadEntity>>

  @Query("SELECT * FROM leads WHERE score = :score ORDER BY timestamp DESC")
  fun getLeadsByScore(score: String): Flow<List<LeadEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertLead(lead: LeadEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(leads: List<LeadEntity>)

  @Update
  suspend fun updateLead(lead: LeadEntity)

  @Delete
  suspend fun deleteLead(lead: LeadEntity)

  @Query("SELECT COUNT(*) FROM leads")
  fun getLeadCount(): Flow<Int>
}
