package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "leads")
data class LeadEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val studentName: String,
  val parentPhone: String,
  val targetCourse: String,
  val inquirySummary: String,
  val score: String, // "HOT", "WARM", "COLD"
  val status: String, // "NEW", "DEMO_SCHEDULED", "FOLLOW_UP", "CONVERTED"
  val timestamp: Long = System.currentTimeMillis(),
  val clientSource: String = "Apex NEET Academy"
)
