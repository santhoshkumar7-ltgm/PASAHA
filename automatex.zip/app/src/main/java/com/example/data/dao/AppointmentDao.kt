package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppointmentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AppointmentDao {
  @Query("SELECT * FROM appointments ORDER BY createdAt DESC")
  fun getAllAppointments(): Flow<List<AppointmentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAppointment(appointment: AppointmentEntity): Long

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(appointments: List<AppointmentEntity>)

  @Update
  suspend fun updateAppointment(appointment: AppointmentEntity)

  @Delete
  suspend fun deleteAppointment(appointment: AppointmentEntity)

  @Query("SELECT COUNT(*) FROM appointments")
  fun getAppointmentCount(): Flow<Int>
}
