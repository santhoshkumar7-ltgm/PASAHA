package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AppointmentSchedulerScreen
import com.example.ui.screens.BusinessStrategyScreen
import com.example.ui.screens.LeadCrmScreen
import com.example.ui.screens.PitchVaultScreen
import com.example.ui.screens.WhatsAppSimulatorScreen
import com.example.ui.theme.AutomateXTheme
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.NeonMint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AgencyViewModel
import com.example.viewmodel.AppTab

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AutomateXTheme {
        AutomateXMainApp()
      }
    }
  }
}

@Composable
fun AutomateXMainApp(
  viewModel: AgencyViewModel = viewModel()
) {
  val currentTab by viewModel.currentTab.collectAsState()

  // Handle back button: return to WhatsApp Simulator if on any other tab
  BackHandler(enabled = currentTab != AppTab.WHATSAPP_SIMULATOR) {
    viewModel.setTab(AppTab.WHATSAPP_SIMULATOR)
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = DarkBackground,
    contentWindowInsets = WindowInsets.safeDrawing,
    bottomBar = {
      NavigationBar(
        containerColor = DarkSurface,
        tonalElevation = 8.dp,
        modifier = Modifier
          .windowInsetsPadding(WindowInsets.navigationBars)
          .testTag("main_bottom_nav")
      ) {
        val navItems = listOf(
          Triple(AppTab.WHATSAPP_SIMULATOR, "Live Bot", Icons.Default.ChatBubble),
          Triple(AppTab.LEAD_CRM, "Leads CRM", Icons.Default.Group),
          Triple(AppTab.APPOINTMENTS, "Bookings", Icons.Default.EventAvailable),
          Triple(AppTab.REVENUE_PLANNER, "ROI Planner", Icons.Default.TrendingUp),
          Triple(AppTab.PITCH_VAULT, "Pitch Vault", Icons.Default.Lightbulb)
        )

        navItems.forEach { (tab, label, icon) ->
          val isSelected = currentTab == tab
          NavigationBarItem(
            selected = isSelected,
            onClick = { viewModel.setTab(tab) },
            icon = {
              Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) EmeraldPrimary else TextMuted
              )
            },
            label = {
              Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) NeonMint else TextSecondary
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = EmeraldPrimary,
              unselectedIconColor = TextMuted,
              selectedTextColor = NeonMint,
              unselectedTextColor = TextSecondary,
              indicatorColor = Color(0xFF132B25)
            ),
            modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (currentTab) {
        AppTab.WHATSAPP_SIMULATOR -> WhatsAppSimulatorScreen(viewModel = viewModel)
        AppTab.LEAD_CRM -> LeadCrmScreen(viewModel = viewModel)
        AppTab.APPOINTMENTS -> AppointmentSchedulerScreen(viewModel = viewModel)
        AppTab.REVENUE_PLANNER -> BusinessStrategyScreen(viewModel = viewModel)
        AppTab.PITCH_VAULT -> PitchVaultScreen(viewModel = viewModel)
      }
    }
  }
}
